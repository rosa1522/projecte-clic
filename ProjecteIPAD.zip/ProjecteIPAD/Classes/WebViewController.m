//
//  WebViewController.m
//  ProjecteIPAD
//
//  Created by DEIM on 22/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "WebViewController.h"


@implementation WebViewController
@synthesize webview;
@synthesize identificadorJoc;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	
	// Obrim la carpeta del joc que hem seleccionat a la llista
	NSMutableString *directoriJoc = [NSMutableString string];	
			
	[directoriJoc appendString: @"/Jocs/"];
	[directoriJoc appendString:[NSString stringWithFormat:@"%@", identificadorJoc]];	
	[directoriJoc appendString: @"/"];
		
	NSLog(@"identificador %@", identificadorJoc);
	NSString *htmlPath = [[NSBundle mainBundle] pathForResource:@"index" ofType:@"html" inDirectory:directoriJoc];
	NSURLRequest *requestObj = [NSURLRequest requestWithURL:[NSURL fileURLWithPath:htmlPath isDirectory:NO]];
	[webview loadRequest:requestObj];
	
	// Definim que no boti la vista web
	[[webview.subviews objectAtIndex:0] setBounces:NO];		
}

- (void)viewDidUnload
{
    [super viewDidUnload];
	
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Fixem la pantalla perquè només es pugui mostrar en horitzontal
    return (interfaceOrientation == UIInterfaceOrientationLandscapeRight || interfaceOrientation == UIInterfaceOrientationLandscapeLeft);
}

@end