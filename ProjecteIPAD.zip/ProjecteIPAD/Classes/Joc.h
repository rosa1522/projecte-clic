//
//  Joc.h
//  ProjecteIPAD
//
//  Created by DEIM on 22/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>


@interface Joc : NSObject {
	
	NSString *identificador;	
	NSString *nom;
	NSString *dataPublicacio;
	NSMutableArray *llengua;
	NSMutableArray *nivellJoc;
	NSMutableArray *area;
	NSString *ruta;
	NSString *clic;
	NSString *img;
	NSString *centre;
	NSString *autors;
}

@property (nonatomic, retain) NSString *identificador;
@property (nonatomic, retain) NSString *nom;
@property (nonatomic, retain) NSString *dataPublicacio;
@property (nonatomic, retain) NSMutableArray *llengua;
@property (nonatomic, retain) NSMutableArray *nivellJoc;
@property (nonatomic, retain) NSMutableArray *area;
@property (nonatomic, retain) NSString *ruta;
@property (nonatomic, retain) NSString *clic;
@property (nonatomic, retain) NSString *img;
@property (nonatomic, retain) NSString *centre;
@property (nonatomic, retain) NSString *autors;

@end
