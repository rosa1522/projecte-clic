//
//  WebViewController.h
//  ProjecteIPAD
//
//  Created by DEIM on 22/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//


#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface WebViewController : UIViewController {
	IBOutlet UIWebView *webview;
	
	NSString *identificadorJoc;
}

@property (nonatomic, retain) IBOutlet UIWebView *webview;
@property (nonatomic, retain) NSString *identificadorJoc;


@end
