//
//  XML_Parser_Descarregats.m
//  ProjecteIPAD
//
//  Created by DEIM on 22/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//


#import "XML_Parser_Descarregats.h"
#import "ProjecteIPADAppDelegate.h"
#import "Joc.h"

@implementation XML_Parser_Descarregats

- (XML_Parser_Descarregats *) initXMLParser_Descarregats {
	
	[super init];
	
	appDelegate = (ProjecteIPADAppDelegate *)[[UIApplication sharedApplication] delegate];
	
	return self;
}

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName 
  namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qualifiedName 
	attributes:(NSDictionary *)attributeDict {
	
	if([elementName isEqualToString:@"descarregats"]) {
		// Inicialitzem la taula de jocs descarregats		
		appDelegate.jocs_descarregats = [[NSMutableDictionary alloc] init];			
	}
	
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string { 
	
	NSString *stringSenseEspais = [string stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];	
	if(!currentElementValue) 
		currentElementValue = [[NSMutableString alloc] initWithString:stringSenseEspais];
	else
		[currentElementValue appendString:stringSenseEspais];	
	
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName 
  namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName {
	
	
	if([elementName isEqualToString:@"descarregats"])
		return;
	
	if([elementName isEqualToString:@"identificador"]) {			
		Joc *aJoc = [appDelegate.jocs objectForKey:currentElementValue];
		[appDelegate.jocs_descarregats setObject:aJoc forKey:currentElementValue];
		
		// Treiem el joc de la llista de jocs i el posem a la llista de descarregats
		[appDelegate.jocs removeObjectForKey:currentElementValue];		
	}
	
	[currentElementValue release];
	currentElementValue = nil;
}


- (void) dealloc {
	[currentElementValue release];
	[super dealloc];
}

@end
