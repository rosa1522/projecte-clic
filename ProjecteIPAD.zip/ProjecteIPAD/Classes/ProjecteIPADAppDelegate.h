//
//  ProjecteIPADAppDelegate.h
//  ProjecteIPAD
//
//  Created by DEIM on 22/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//



#import <UIKit/UIKit.h>

@class ProjecteIPADViewController;

@interface ProjecteIPADAppDelegate : NSObject <UIApplicationDelegate> {
    
    UIWindow *window;
	ProjecteIPADViewController *viewController;
	
	NSMutableDictionary *jocs;
	NSMutableDictionary *jocs_descarregats;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet ProjecteIPADViewController *viewController;

@property (nonatomic, retain) NSMutableDictionary *jocs;
@property (nonatomic, retain) NSMutableDictionary *jocs_descarregats;


@end

