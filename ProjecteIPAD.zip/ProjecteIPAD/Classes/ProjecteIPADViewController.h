//
//  ProjecteIPADViewController.h
//  ProjecteIPAD
//
//  Created by DEIM on 22/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//


#import <UIKit/UIKit.h>

@class ProjecteIPADAppDelegate, DescripcioJocViewController, LlistaJocsJClicController;

@interface ProjecteIPADViewController : UIViewController {
	
	ProjecteIPADAppDelegate *appDelegate;
	LlistaJocsJClicController *bdvControllerLlista;
	DescripcioJocViewController *bdvControllerDescripcio;
	
	IBOutlet UITableView *tableView;	
	UIButton *buttonLlistaJocs;
	
}

@property (nonatomic, retain) IBOutlet UIButton *buttonLlistaJocs;

-(IBAction) do_button_press:(id) sender;

@end