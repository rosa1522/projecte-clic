//
//  XML_Parser_Descarregats.h
//  ProjecteIPAD
//
//  Created by DEIM on 22/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@class ProjecteIPADAppDelegate;

@interface XML_Parser_Descarregats: NSObject<NSXMLParserDelegate>{
	
	NSMutableString *currentElementValue;	
	ProjecteIPADAppDelegate *appDelegate;
}

- (XML_Parser_Descarregats *) initXMLParser_Descarregats;

@end