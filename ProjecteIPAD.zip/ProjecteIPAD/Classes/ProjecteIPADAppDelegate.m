//
//  ProjecteIPADAppDelegate.m
//  ProjecteIPAD
//
//  Created by DEIM on 22/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ProjecteIPADViewController.h"
#import "ProjecteIPADAppDelegate.h"
#import "XML_Parser_Jocs.h"
#import "XML_Parser_Descarregats.h"

@implementation ProjecteIPADAppDelegate

@synthesize window;
@synthesize viewController;
@synthesize jocs, jocs_descarregats;


#pragma mark -
#pragma mark Application lifecycle

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {    
    
	//*********************************
	// Llegim l'XML de tots els jocs 
	//*********************************
	NSString* path = [[NSBundle mainBundle] pathForResource: @"jocs_curt" ofType: @"xml"];
	NSData* data = [NSData dataWithContentsOfFile: path];
	NSXMLParser* xmlParser = [[NSXMLParser alloc] initWithData: data];	
	
	XML_Parser_Jocs *parser = [[XML_Parser_Jocs alloc] initXMLParser];	
	[xmlParser setDelegate:parser];		
	BOOL success = [xmlParser parse];
	
	if(!success)
		NSLog(@"Error al llegir l'XML dels jocs!!!");
	
	//********************************************************
	// Llegim l'XML dels jocs descarregats de dintre l'IPAD	
	//********************************************************
	NSString *docsDirectory = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0]; 
	NSString *path_desc = [docsDirectory stringByAppendingPathComponent:@"descarregats.xml"];  
	NSFileManager *fileManager = [NSFileManager defaultManager]; 
	if ([fileManager fileExistsAtPath:path_desc]) {
		NSData* data_desc = [NSData dataWithContentsOfFile: path_desc];
		NSXMLParser* xmlParser_desc = [[NSXMLParser alloc] initWithData: data_desc];	
		
		XML_Parser_Descarregats *parser_desc = [[XML_Parser_Descarregats alloc] initXMLParser_Descarregats];	
		[xmlParser_desc setDelegate:parser_desc];		
		BOOL success_desc = [xmlParser_desc parse];
		
		if(!success_desc)
			NSLog(@"Error al llegir a l'XMl dels jocs descarregats!!!");
	}else {
		// Inicialitzem la taula dels jocs descarregats ja que sino tenim fitxer 
		// de jocs_descarregats no entrem al XML_Parser_Descarregats i no s'inicialitzaria
		jocs_descarregats = [[NSMutableDictionary alloc] init];	
	}; 	
	
	// Obrim la pantalla principal (llista amb els jocs descarregats)
	ProjecteIPADViewController *wltvc = [[ProjecteIPADViewController alloc] init];
	UINavigationController *nav = [[UINavigationController alloc] init];
	[nav pushViewController:wltvc animated:YES];
	[wltvc release];
	
	[window addSubview:nav.view];
	[window makeKeyAndVisible];
	
	
	return YES;
}


#pragma mark -
#pragma mark Memory management

- (void)dealloc {
	[jocs release];
	[jocs_descarregats release];
	[viewController release];
    [window release];
    [super dealloc];
}


@end

