//
//  ProjecteIPADViewController.m
//  ProjecteIPAD
//
//  Created by DEIM on 22/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ProjecteIPADViewController.h"
#import "ProjecteIPADAppDelegate.h"
#import "DescripcioJocViewController.h"
#import "LlistaJocsJClicController.h"
#import "Joc.h"

@implementation ProjecteIPADViewController
@synthesize buttonLlistaJocs;


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [appDelegate.jocs_descarregats count];
}

- (UITableViewCell *)tableView:(UITableView *)table cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    }
	
	// Posem el nom del joc a la cel·la de la taula
	NSArray *allKeys = [appDelegate.jocs_descarregats allKeys];
	Joc *aJoc = [appDelegate.jocs_descarregats objectForKey:[allKeys objectAtIndex:indexPath.row]];
	cell.textLabel.text = aJoc.nom;
	
	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	
	if(bdvControllerDescripcio == nil)
		bdvControllerDescripcio = [[DescripcioJocViewController alloc] initWithNibName:@"DescripcioJocViewController" bundle:[NSBundle mainBundle]];
	
	
	NSArray *allKeys = [appDelegate.jocs_descarregats allKeys];
	Joc *aJoc = [appDelegate.jocs_descarregats objectForKey:[allKeys objectAtIndex:indexPath.row]];
	
	// Passem el joc seleccionat a la pantalla 
	bdvControllerDescripcio.aJoc = aJoc;
	
	[self.navigationController pushViewController:bdvControllerDescripcio animated:YES];
		
}

-(IBAction) do_button_press:(id)sender{		

	bdvControllerLlista = [[LlistaJocsJClicController alloc] initWithNibName:@"LlistaJocsJClicController" bundle:[NSBundle mainBundle]];
	[self.navigationController pushViewController:bdvControllerLlista animated:YES];
	
}

- (void)viewDidLoad {
    [super viewDidLoad];
	
	appDelegate = (ProjecteIPADAppDelegate *)[[UIApplication sharedApplication] delegate];
	
	self.title = @"Juga amb ...";
}


- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	
	// Refresquem la llista dels jocs descarregats
	[tableView reloadData];
}



- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
	// Deixem que la orientació de la pantalla sigui tant en vertical com en horitzontal
	return YES;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


- (void)dealloc {
	[tableView release];
	[bdvControllerLlista release];
	[bdvControllerDescripcio release];
	[appDelegate release];	
    [super dealloc];
}

@end






