//
//  Joc.m
//  ProjecteIPAD
//
//  Created by DEIM on 22/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Joc.h"


@implementation Joc

@synthesize area, nivellJoc, llengua, identificador, nom, dataPublicacio, ruta, clic, img, centre, autors;


- (void) dealloc {
	
	[area release];
	[nivellJoc release];
	[llengua release];	
	[identificador release];
	[nom release];
	[dataPublicacio release];
	[ruta release];
	[clic release];
	[img release];
	[centre release];
	[autors release];
	[super dealloc];
}

@end
