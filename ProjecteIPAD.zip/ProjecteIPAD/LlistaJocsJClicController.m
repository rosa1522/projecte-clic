//
//  LlistaJocsJClicController.m
//  ProjecteIPAD
//
//  Created by DEIM on 22/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//


#import "LlistaJocsJClicController.h"
#import "ProjecteIPADAppDelegate.h"
#import "DescripcioJocViewController.h"
#import "Joc.h"


@implementation LlistaJocsJClicController


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [appDelegate.jocs count];
}

- (UITableViewCell *)tableView:(UITableView *)table cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier] autorelease];
    }
	
	// Posem el nom del joc a la cel·la de la taula
	NSArray *allKeys = [appDelegate.jocs allKeys];
	Joc *aJoc = [appDelegate.jocs objectForKey:[allKeys objectAtIndex:indexPath.row]];	
	cell.textLabel.text = aJoc.nom;
	
	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	if(bdvController == nil)
		bdvController = [[DescripcioJocViewController alloc] initWithNibName:@"DescripcioJocViewController" bundle:[NSBundle mainBundle]];
	
	NSArray *allKeys = [appDelegate.jocs allKeys];
	Joc *aJoc = [appDelegate.jocs objectForKey:[allKeys objectAtIndex:indexPath.row]];
	
	bdvController.aJoc = aJoc;
	
	[self.navigationController pushViewController:bdvController animated:YES];
}


- (void)viewDidLoad {
    [super viewDidLoad];
	
	appDelegate = (ProjecteIPADAppDelegate *)[[UIApplication sharedApplication] delegate];
	
	self.title = @"Afegir un joc";
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	
	// Refresquem la llista dels jocs
	[tableView reloadData];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
	// Deixem que la orientació de la pantalla sigui tant en vertical com en horitzontal
    return YES;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning]; 
}


- (void)dealloc {
	[bdvController release];
	[appDelegate release];
    [super dealloc];
}

@end
