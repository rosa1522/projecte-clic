//
//  DescripcioJocViewController.h
//  ProjecteIPAD
//
//  Created by DEIM on 22/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@class Joc, WebViewController, ProjecteIPADAppDelegate;

@interface DescripcioJocViewController : UIViewController {
	
	IBOutlet UITableView *tableView;
	UIButton *buttonWebView;
	
	ProjecteIPADAppDelegate *appDelegate;
	WebViewController *bdvController;
	
	Joc *aJoc;
}


@property (nonatomic, retain) Joc *aJoc;
@property (nonatomic, retain) IBOutlet UIButton *buttonWebView;

-(IBAction) do_button_press:(id) sender;

@end