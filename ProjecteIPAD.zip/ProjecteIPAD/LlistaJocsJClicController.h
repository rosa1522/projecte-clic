//
//  LlistaJocsJClicController.h
//  ProjecteIPAD
//
//  Created by DEIM on 22/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@class ProjecteIPADAppDelegate, DescripcioJocViewController;

@interface LlistaJocsJClicController : UIViewController {
	
	ProjecteIPADAppDelegate *appDelegate;
	DescripcioJocViewController *bdvController;
	
	IBOutlet UITableView *tableView;
}

@end

