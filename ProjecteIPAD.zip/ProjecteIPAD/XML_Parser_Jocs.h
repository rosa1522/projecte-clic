//
//  XML_Parser_Jocs.h
//  ProjecteIPAD
//
//  Created by DEIM on 22/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>


@class ProjecteIPADAppDelegate, Joc;

@interface XML_Parser_Jocs: NSObject<NSXMLParserDelegate>{
	
	NSMutableString *currentElementValue;
	
	ProjecteIPADAppDelegate *appDelegate;
	Joc *aJoc; 
	NSString *nodeFill;
}

@property (nonatomic, retain) NSString *nodeFill;

- (XML_Parser_Jocs *) initXMLParser;

@end