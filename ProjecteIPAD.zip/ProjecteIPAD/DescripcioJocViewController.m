//
//  DescripcioJocViewController.m
//  ProjecteIPAD
//
//  Created by DEIM on 22/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//


#import "DescripcioJocViewController.h"
#import "ProjecteIPADAppDelegate.h"
#import "WebViewController.h"
#import "Joc.h"

@implementation DescripcioJocViewController

@synthesize aJoc;
@synthesize buttonWebView;


- (void)viewDidLoad {
 	[super viewDidLoad];
	
	self.title = @"Descripció del joc";
		
	appDelegate = (ProjecteIPADAppDelegate *)[[UIApplication sharedApplication] delegate];
	
}

-(IBAction) do_button_press:(id)sender{	
	Joc *joc = [appDelegate.jocs_descarregats objectForKey:aJoc.identificador];	
	
	// Si el joc no està descarregat l'hem de descarregar, actualitzar les llistes 
	// i actualitzar el fitxer descarregats.xml
	if (joc != nil) {		
		bdvController = [[WebViewController alloc] initWithNibName:@"WebViewController" bundle:[NSBundle mainBundle]];
		
		// Passem l'identificador del joc per poder obrir 
		bdvController.identificadorJoc = aJoc.identificador;
		
		[self.navigationController pushViewController:bdvController animated:YES];
		
	}else{
		// Treiem el joc de la llista de jocs i el posem a la llista de descarregats
		[appDelegate.jocs_descarregats setObject:aJoc forKey:aJoc.identificador];
		[appDelegate.jocs removeObjectForKey:aJoc.identificador];
				
		
		//*************************************
		// Escriure al fitxer de descarregats
		//**************************************
		NSString *ident = @"<?xml version=\"1.0\"?> \n <descarregats> \n";	
		NSArray *taulaClaus = [appDelegate.jocs_descarregats allKeys];	
		for (int i=0; i < appDelegate.jocs_descarregats.count; i++) {			
			ident = [ident stringByAppendingString: @"\t<identificador>"];		
			ident = [ident stringByAppendingString:[taulaClaus objectAtIndex:i]];		
			ident = [ident stringByAppendingString: @"</identificador>\n"];		
		}	
		ident = [ident stringByAppendingString:@"</descarregats>"];
		NSString *docsDirectory = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0]; 
		NSString *path_desc = [docsDirectory stringByAppendingPathComponent:@"descarregats.xml"];  
		
		NSData *dataToWrite = [[NSString stringWithString:ident] dataUsingEncoding:NSUTF8StringEncoding];  
		[dataToWrite writeToFile:path_desc atomically:YES];  
		
		// Canviem la imatge del botó
		UIImage *iImatgeBoto = [UIImage imageNamed:@"play.png"];		
		[buttonWebView setImage:iImatgeBoto forState:UIControlStateNormal];
	}	

}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	
	// Mirem si el joc està descarregat per mostrar l'icone de jugar o de descarregar
	Joc *joc = [appDelegate.jocs_descarregats objectForKey:aJoc.identificador];	
	UIImage *iImatgeBoto = nil;
	if (joc != nil) {
		iImatgeBoto = [UIImage imageNamed:@"play.png"];	
	}else {
		iImatgeBoto = [UIImage imageNamed:@"import.png"];
	}	
	[buttonWebView setImage:iImatgeBoto forState:UIControlStateNormal];
	
	[tableView reloadData];
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
	// Deixem que la orientació de la pantalla sigui tant en vertical com en horitzontal
    return YES;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 7;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tv cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier] autorelease];
    }
	
	
	NSArray *keysIdiomes = [NSArray arrayWithObjects:@"tot", @"de", @"en", @"arn", @"eu", @"rmq", @"ca", @"es", @"eo", @"fr", @"gl", @"el", @"it", @"la", @"oc", @"pt", @"ro", @"sv",@"zh",nil];	
	NSArray *objectsIdiomes = [NSArray arrayWithObjects:@"Tots els idiomes", @"Alemany", @"Anglès", @"Araucà", @"Basc", @"Caló", @"Català",							 
							   @"Espanyol", @"Esperanto", @"Francès", @"Gallec", @"Grec", @"Italià", @"Llatí", @"Occità", @"Portuguès",							 
							   @"Romanès", @"Suec", @"Xinès", nil];			
	NSDictionary *idiomes = [NSDictionary dictionaryWithObjects:objectsIdiomes forKeys:keysIdiomes];	
	
	
	NSArray *keysNivells = [NSArray arrayWithObjects:@"tot", @"ei", @"ep", @"eso", @"ba", nil]; 
	NSArray *objectsNivells = [NSArray arrayWithObjects:@"Tots els nivells", @"Infantil (3-6)", @"Primària (6-12)", @"Ciències socials (12-16)", @"Batxillerat (16-18)", nil];
	NSDictionary *nivells = [NSDictionary dictionaryWithObjects:objectsNivells forKeys:keysNivells];	
	
	
	NSArray *keysArees = [NSArray arrayWithObjects: @"tot", @"lleng", @"mat", @"soc", @"exp", @"mus", @"vip", @"ef", @"tec", @"div",nil];	
	NSArray *objectsArees = [NSArray arrayWithObjects:@"Totes les àrees", @"Llengües", @"Matemàtiques", @"Ciències socials", @"Ciències experimentals", @"Música", @"Visual i Plàstica", @"Educació física", @"Tecnologies", @"Diversos", nil];	
	NSDictionary *arees = [NSDictionary dictionaryWithObjects:objectsArees forKeys:keysArees];	
	
	
	NSMutableString* nivell = [NSMutableString string];			
	NSMutableString* area = [NSMutableString string];		
	NSMutableString* llengua = [NSMutableString string];	
	
	switch(indexPath.section)
	{
		case 0:
			cell.textLabel.text = aJoc.nom;
			break;
			
		case 1:
			for (int i = 0; i <= (aJoc.area.count-1); i++){
				NSString *nomArea = [arees objectForKey:[aJoc.area objectAtIndex:i]];
				if (i == 0){
					[area appendString:[NSString stringWithFormat:@"%@", nomArea]];
				}else{
					[area appendString:[NSString stringWithFormat:@", %@", nomArea]];
				}		
			}			
			cell.textLabel.text = area;
			break;
			
		case 2:
			for (int i = 0; i <= (aJoc.nivellJoc.count-1); i++){
				NSString *nomNivell = [nivells objectForKey:[aJoc.nivellJoc objectAtIndex:i]];
				if (i == 0){
					[nivell appendString:[NSString stringWithFormat:@"%@", nomNivell]];
				}else{
					[nivell appendString:[NSString stringWithFormat:@", %@", nomNivell]];
				}		
			}				
			cell.textLabel.text = nivell;
			break;
			
		case 3:						
			cell.textLabel.text = aJoc.dataPublicacio;
			break;	
			
		case 4:		
			for (int i = 0; i < aJoc.llengua.count; i++){					
				NSString *nomllengua = [idiomes objectForKey:[aJoc.llengua objectAtIndex:i]];
				if (i == 0){			
					[llengua appendString:[NSString stringWithFormat:@"%@", nomllengua]];
				}else{
					[llengua appendString:[NSString stringWithFormat:@", %@", nomllengua]];
				}				
			}
			
			cell.textLabel.text = llengua;
			break;		
			
		case 5:						
			cell.textLabel.text = aJoc.autors;
			break;	
			
		case 6:
			cell.textLabel.text = aJoc.centre;
			break;	
	}
	
	return cell;
}

- (NSString *)tableView:(UITableView *)tblView titleForHeaderInSection:(NSInteger)section {
	
	NSString *sectionName = nil;
	
	switch(section)
	{
		case 0:
			sectionName = [NSString stringWithString:@"Nom"];
			break;
		case 1:
			sectionName = [NSString stringWithString:@"Àrea"];
			break;
		case 2:
			sectionName = [NSString stringWithString:@"Nivell"];
			break;
		case 3:
			sectionName = [NSString stringWithString:@"Data"];
			break;
		case 4:
			sectionName = [NSString stringWithString:@"Idioma"];
			break;	
		case 5:
			sectionName = [NSString stringWithString:@"Autor/a"];
			break;	
		case 6:
			sectionName = [NSString stringWithString:@"Centre"];
			break;	
	}
	
	return sectionName;
}

- (void)dealloc {
	
	[bdvController release];
	[aJoc release];
	[tableView release];
    [super dealloc];
}

@end
