//
//  XML_Parser_Jocs.m
//  ProjecteIPAD
//
//  Created by DEIM on 22/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "XML_Parser_Jocs.h"
#import "ProjecteIPADAppDelegate.h"
#import "Joc.h"


@implementation XML_Parser_Jocs
@synthesize nodeFill;

- (XML_Parser_Jocs *) initXMLParser {
	
	[super init];
	
	appDelegate = (ProjecteIPADAppDelegate *)[[UIApplication sharedApplication] delegate];
	
	return self;
}

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName 
  namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qualifiedName 
	attributes:(NSDictionary *)attributeDict {
	
	
	if([elementName isEqualToString:@"jclic"]) {
		// Inicialitzem la taula de jocs			
		appDelegate.jocs = [[NSMutableDictionary alloc] init];
	}
	else if([elementName isEqualToString:@"joc"]) {
		
		// Inicialitzem el Joc
		aJoc = [[Joc alloc] init];
		
		// Inicialitzem la taula de noms dels idiomes, nivells i arees
		aJoc.llengua = [[NSMutableArray alloc] init];
		aJoc.nivellJoc = [[NSMutableArray alloc] init];
		aJoc.area = [[NSMutableArray alloc] init];
		
	}
	else if ([elementName isEqualToString:@"llengua"]){		
		nodeFill = @"llengua";				
	}
	else if ([elementName isEqualToString:@"nivellJoc"]){
		nodeFill = @"nivellJoc";
	}
	else if ([elementName isEqualToString:@"area"]){		
		nodeFill = @"area";				
	}
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string { 
	
	NSString *stringSenseEspais = [string stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	if(!currentElementValue) 
		currentElementValue = [[NSMutableString alloc] initWithString:stringSenseEspais];
	else{
		[currentElementValue appendString:stringSenseEspais];
	}
	
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName 
  namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName {
	
	
	if([elementName isEqualToString:@"jclic"])
		return;
	
	
	if([elementName isEqualToString:@"joc"]) {
		[appDelegate.jocs setObject:aJoc forKey: aJoc.identificador]; 
		
		[aJoc release];
		aJoc = nil;
	}
	else if ([elementName isEqualToString:@"llengua"]){
		nodeFill = nil;
	}	
	else if ([elementName isEqualToString:@"nivellJoc"]){
		nodeFill = nil;		
	}
	else if ([elementName isEqualToString:@"area"]){
		nodeFill = nil;		
	}
	else if ([elementName isEqualToString:@"nom"] && [nodeFill isEqualToString:@"llengua"]){
		[aJoc.llengua addObject:currentElementValue];		
	}
	else if ([elementName isEqualToString:@"nom"] && [nodeFill isEqualToString:@"nivellJoc"]){
		[aJoc.nivellJoc addObject:currentElementValue];		
	}
	else if ([elementName isEqualToString:@"nom"] && [nodeFill isEqualToString:@"area"]){
		[aJoc.area addObject:currentElementValue];		
	}
	else
		[aJoc setValue:currentElementValue forKey:elementName];
	
	
	[currentElementValue release];
	currentElementValue = nil;
}


- (void) dealloc {
	
	[aJoc release];
	[currentElementValue release];
	[super dealloc];
}

@end